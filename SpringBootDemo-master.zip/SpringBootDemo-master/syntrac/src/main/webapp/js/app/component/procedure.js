define(['ko'], function(ko) {
	
	function Procedure() {
		
	};
	
	return Procedure;
});
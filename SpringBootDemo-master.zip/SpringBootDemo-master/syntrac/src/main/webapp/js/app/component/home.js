define(['ko'], function(ko) {
	
	function Home() {
		
	};
	
	return Home;
});
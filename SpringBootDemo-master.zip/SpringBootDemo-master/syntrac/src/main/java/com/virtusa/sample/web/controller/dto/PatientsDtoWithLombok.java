package com.virtusa.sample.web.controller.dto;

import org.springframework.stereotype.Component;

@Component
public class PatientsDtoWithLombok {

//	@NotNull @Getter @Setter String firstName;
//
//	@NotNull @Getter @Setter String lastName;
//	
//	@Getter @Setter DateTime dob;
//	
//	@Getter @Setter Double weight;
//	
//	@Getter @Setter Long mrn;
//	
//	@Getter @Setter String gender; 
//	
//	@Getter @Setter Long phone1;
//	
//	@Getter @Setter Long phone2;
//	
//	@Getter @Setter String line1; 
//	
//	@Getter @Setter String line2; 
//	
//	@Getter @Setter String city;
//	
//	@Getter @Setter String state; 
//	
//	@Getter @Setter Integer zip;
//	
//	@Getter @Setter String email; 
//	
//	@Getter @Setter String maritalStatus;
}

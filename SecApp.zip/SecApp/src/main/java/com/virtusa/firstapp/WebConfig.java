package com.virtusa.firstapp;

public class WebConfig {

}

package com.virtusa.firstapp;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppLauncher {
	public static void main(String[] args) {

	}
}
